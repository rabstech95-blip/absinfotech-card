// Tab switching
document.querySelectorAll('.tablink').forEach(btn=>{
  btn.addEventListener('click',()=>{
    document.querySelectorAll('.tablink').forEach(b=>b.classList.remove('active'));
    document.querySelectorAll('.tabcontent').forEach(s=>s.classList.remove('active'));
    btn.classList.add('active');
    const id = btn.getAttribute('data-tab');
    document.getElementById(id).classList.add('active');
    window.scrollTo({ top: document.querySelector('.tabs').offsetTop, behavior: 'smooth' });
  });
});

// Enquiry form -> open WhatsApp with prefilled message
const form = document.getElementById('enquiryForm');
if(form){
  form.addEventListener('submit', function(e){
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const mobile = document.getElementById('mobile').value.trim();
    const message = document.getElementById('message').value.trim();
    if(!name || !mobile){ alert('Please enter your name and mobile number.'); return; }
    const text = `New enquiry from ABS Digital Card:%0A%0AName: ${encodeURIComponent(name)}%0AMobile: ${encodeURIComponent(mobile)}%0ARequirement: ${encodeURIComponent(message||'-')}`;
    const url = `https://wa.me/919130249995?text=${text}`;
    window.open(url, '_blank');
  });
}
